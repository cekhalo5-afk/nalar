# Nalar — proyek Android (TWA)

Pembungkus APK untuk web app Nalar. APK ini hanya membuka situs Nalar lewat Chrome (Trusted Web Activity),
sehingga WebGPU dan model AI berjalan seperti di browser. Model & data tersimpan di penyimpanan Chrome.

## Sebelum build — WAJIB
1. Web app Nalar (zip pertama) harus sudah di-hosting dengan HTTPS, mis. GitHub Pages.
2. Ubah `NALAR_URL` di `gradle.properties` ke alamat itu, atau beri saat build: `-PNALAR_URL=https://...`
   Jika tidak diubah, APK akan membuka alamat contoh yang tidak ada.

## Build
- Android Studio: Open proyek ini → Build → Build APK(s) / Generate Signed Bundle-APK.
- Command line / bot: `gradle assembleRelease` (JDK 17+, Android SDK 34, Gradle 9.1+).
  Hasil: `app/build/outputs/apk/release/app-release.apk`.
- File `gradlew` & `gradle-wrapper.jar` TIDAK disertakan (biner). Jika bot Anda memerlukannya, jalankan `gradle wrapper` sekali.

## Penandatanganan
Build release memakai kunci debug agar langsung bisa dipasang (pemakaian pribadi saja, bukan Google Play).
Jika bot Anda menandatangani dengan keystore sendiri, hapus baris `signingConfig signingConfigs.debug` di `app/build.gradle`.

## Keterbatasan
- Perangkat butuh Chrome dengan WebGPU (umumnya Android 12+ dan GPU yang didukung). Tanpa itu, chat AI tidak jalan.
- Belum ada verifikasi Digital Asset Links, jadi bar alamat Chrome mungkin tampil di atas aplikasi. Mode layar penuh
  butuh file `/.well-known/assetlinks.json` di situs dan sidik jari SHA-256 kunci tanda tangan APK.
- Proyek ini BELUM pernah di-build (sandbox tidak punya Android SDK/internet). Versi AGP 9.0.0 dan
  androidbrowserhelper 2.5.0 dipilih dari pengetahuan saya; jika bot melaporkan error dependensi, kirim lognya.
